<template>
  <div class="x6-graph-wrap">
    <div ref="container" class="x6-graph" />
  </div>
</template>

<script lang="ts">
import '../index.less'
import {defineComponent} from "vue";
import { Graph } from '@antv/x6'
export default defineComponent({
  name: "clean",
  mounted() {
    const graph = new Graph({
      container: (this.$refs.container) as HTMLDivElement,
      width: 800,
      height: 600,
      grid: {
        visible: true,
      },
      panning: true,
    })
    const source = graph.addNode({
      x: 40,
      y: 40,
      width: 80,
      height: 30,
      label: 'Source',
      tools: ['button-remove'],
    })

    const target = graph.addNode({
      x: 160,
      y: 240,
      width: 80,
      height: 30,
      label: 'Target',
      tools: ['button-remove'],
    })

    const edge = graph.addEdge({
      source,
      target,
      vertices: [
        { x: 80, y: 160 },
        { x: 200, y: 160 },
      ],
      tools: ['vertices', 'segments'],
    })

    console.log(edge)
    // graph.clearCells()
    // edge.removeTools()
  }
})
</script>

<style scoped>

</style>
