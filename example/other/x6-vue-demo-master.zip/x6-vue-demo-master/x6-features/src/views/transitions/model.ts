import { Model } from '@antv/x6'
import { Star, Name, Connection } from './shapes'

export class Universe extends Model {
  getConstellation(name: string) {
    let constellationStars:any = []
    let stars = this.getNodes()
    for (let i = 0, n = stars.length; i < n; i++) {
      let star = stars[i]
      if (star.prop('constellation') === name) {
        constellationStars.push(star)
      }
    }
    return constellationStars
  }

  getConstellationBBox(name: string) {
    return this.getCellsBBox(this.getConstellation(name))
  }

  loadConstellations(constellations: any) {
    for (let name in constellations) {
      let constellation = constellations[name]
      let stars = constellation.stars || []
      // Add stars
      for (let i = 0, n = stars.length; i < n; i++) {
        let star = stars[i]
        new Star({ id: name + '-' + i })
          .position(star.x, star.y)
          .prop('constellation', name)
          .addTo(this)
      }
      // Add connections
      let connections = constellation.connections || []
      for (let j = 0, m = connections.length; j < m; j++) {
        let connection = connections[j]
        new Connection({
          source: { cell: name + '-' + connection[0] },
          target: { cell: name + '-' + connection[1] },
          constellation: name,
        }).addTo(this)
      }
      // Add constellation name
      let center = this.getConstellationBBox(name)!.getCenter()
      new Name()
        .attr('text/text', name.toUpperCase())
        .position(center.x, center.y)
        .prop('constellation', name)
        .addTo(this)
    }
  }

  highlightConstellation(name: string) {
    var constellation = this.getConstellation(name)
    var subgraph = this.getSubGraph(constellation)
    for (var i = 0, n = subgraph.length; i < n; i++) {
      var cell = subgraph[i]
      if (cell.isEdge()) {
        (cell as Connection).highlight()
      }
    }
  }

  unhighlightConstellation(name: string) {
    var constellation = this.getConstellation(name)
    var subgraph = this.getSubGraph(constellation)
    for (var i = 0, n = subgraph.length; i < n; i++) {
      var cell = subgraph[i]
      if (cell.isEdge()) {
        (cell as Connection).unhighlight()
      }
    }
  }
}
