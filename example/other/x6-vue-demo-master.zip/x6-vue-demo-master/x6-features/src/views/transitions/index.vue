<template>
  <div class="x6-graph-wrap">
    <div ref="container" class="x6-graph" />
  </div>
</template>

<script lang="ts">
import '../index.less'
import { defineComponent } from "vue"
import { Graph, Node } from '@antv/x6'
import { Universe } from './model'
import { data } from './data'


export default defineComponent({
  name: "Index",
  mounted() {
    const model = new Universe()
    const graph = new Graph({
      model,
      container: (this.$refs.container) as HTMLDivElement,
      interacting: false,
      width: 800,
      height: 600,
      scroller: {
        enabled: true,
        padding: 0,
        fitTocontentOptions: {
          allowNewOrigin: 'any',
          padding: 1000,
        },
      },
    })

    graph.lockScroller()
    model.loadConstellations(data)
    graph.updateScroller()

    function focusStars(stars: Node[] = model.getNodes()) {
      graph.transitionToRect(graph.getCellsBBox(stars)!, {
        visibility: 0.8,
        timing: 'ease-out',
        delay: '10ms',
        scaleGrid: 0.05,
      })
    }

    graph.on('cell:mouseup', ({ cell }) => {
      const name = cell.prop('constellation')
      var constellation = model.getConstellation(name)
      focusStars(constellation)
    })

    graph.on('blank:mousedown', () => {
      focusStars()
    })

    graph.on('cell:mouseenter', ({ cell }) => {
      const name = cell.prop('constellation')
      if (name) {
        model.highlightConstellation(name)
      }
    })

    graph.on('cell:mouseleave', ({ cell }) => {
      const name = cell.prop('constellation')
      if (name) {
        model.unhighlightConstellation(name)
      }
    })

  }
})
</script>

<style scoped>

</style>
