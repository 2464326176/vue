<template>
  <div id="app">
      <a-row style="margin-top:10px">
        <a-col :span="4">
          <a-button type="primary" @click="$refs.flow.showDrawer()">流程图</a-button>
        </a-col>
        <a-col :span="4">
          <a-button type="primary" @click="$refs.orgal.showDrawer()">组织架构图（自动布局）</a-button>
        </a-col>
        <a-col :span="4">
          <a-button type="primary" @click="$refs.vso.showDrawer()">vso</a-button>
        </a-col>
        <a-col :span="4">
          <a-button type="primary" @click="$refs.er.showDrawer()">er</a-button>
        </a-col>
        <a-col :span="4">
          <a-button type="primary" @click="$refs.dag.showDrawer()">dag</a-button>
        </a-col>
      </a-row>
    <flow ref="flow"/>
    <orgal ref="orgal"/>
    <vso ref="vso"/>
    <er ref="er"/>
    <dag ref="dag"/>
  </div>
</template>

<script>

import flow from './views/flow/index'
import orgal from './views/orgal/index'
import vso from './views/vso/index'
import er from './views/er/index'
import dag from './views/dag/index'
export default {
  components: {
    flow,
    orgal,
    vso,
    er,
    dag
  },
  data () {
    return {
    }
  }
}
</script>

<style lang="less">
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
}

#nav {
  padding: 30px;

  a {
    font-weight: bold;
    color: #2c3e50;

    &.router-link-exact-active {
      color: #42b983;
    }
  }
}
</style>
