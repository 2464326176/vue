<template>
  <div class="container">
    <a-button @click="changeSize()">change size</a-button>
  </div>
</template>

<script>
export default {
  name: 'ChangeSize',
  props: {
    size: {
      type: Number,
      default: null,
      required: false
    }
  },
  inject: ['getNode', 'getGraph'],
  methods: {
    changeSize () {
      const node = this.getNode()
      const size = node.size()
      node.size(size.width + 5, size.height + 5)
    }
  }
}
</script>
<style scoped>
.container {
  height: 100%;
  display: flex;
  align-items: center;
  justify-content: center;
}
</style>
